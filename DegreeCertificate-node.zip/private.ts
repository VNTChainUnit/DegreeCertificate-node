export default {
    dubbo:{
        host:'122.9.140.211:2181'
    },
    vnt:{
    vnt_accountpwd:"",
    vnt_contractAddress:"0xe9907f03ba3751d77213f671ff00211c0212bbf3",
    },
    secret:"GgX5jYPe"
}
