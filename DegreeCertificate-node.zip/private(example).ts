export default {
    dubbo:{
        host:'172.0.0.1:2181'
    },
    vnt:{
    vnt_accountpwd:"", //your account pwd
    vnt_contractAddress:"", //your contract address
    },
    secret:"" ,//your secret
}